#include <iostream>
#include <SDL3/SDL.h>
#include <thread>
#include <algorithm>
#include <vector>
#include <barrier>
#include <chrono>
#include <atomic>

int win_x = 800; int win_y = std::ceil((float)win_x * 12.0f / 16.0f);
double h_win_x = (double)win_x / 2.0; double h_win_y = (double)win_y / 2.0;

double cam_x = 0;
double cam_y = 0;

double zoom = 150.0;
double inv_zoom = 1.0 / zoom;

int res = 300;

int mouse_x;
int mouse_y;

bool lmb = false;

constexpr int target_fps = 80;

unsigned int hc = std::thread::hardware_concurrency();

unsigned int thread_count = (hc > 1) ? (hc - 1) : 1;

std::barrier thread_barrier(thread_count + 1);

std::vector<std::thread> threads;

float chunk = (float)win_y / (float)thread_count;

std::atomic<bool> terminate_thread{false};

bool window_updated = false;

bool active = true;

struct complex {
    double real, imag;
};

struct rgb_color {
    Uint8 r, g, b;
};

struct point {
    double x, y;
};

struct normalized_rgb {
    double r, g, b;
};

std::vector<rgb_color> pixels;

std::vector<point> escape_path;

constexpr int num_colors = 10;
std::vector<normalized_rgb> color_palette;

void execute_thread(int id) {
    double last_cam_x = INFINITY;
    double last_cam_y = INFINITY;
    double last_zoom = 0;
    double last_res = 0;

    while (true) {
        thread_barrier.arrive_and_wait();

        if (terminate_thread.load()) break;

        if (last_cam_x != cam_x || last_cam_y != cam_y || last_zoom != zoom || last_res != res || window_updated) {
            last_cam_x = cam_x;
            last_cam_y = cam_y;
            last_zoom = zoom;
            last_res = res;

            int start = std::round((float)id * chunk);
            int end = std::min<int>(std::round((float)(id + 1) * chunk), win_y);

            double zoom_factor = 1.0 / std::log(zoom);

            for (int dy = start; dy < end; ++dy) {
                int offset = win_x * dy;

                for (int dx = 0; dx < win_x; ++dx) {
                    complex c = {((double)dx + 0.5 - h_win_x) * inv_zoom + cam_x, ((double)dy + 0.5 - h_win_y) * inv_zoom + cam_y};

                    complex z = {0.0,0.0};

                    rgb_color color{0,0,0};

                    for (int i = 0; i < res; ++i) {
                        complex z2 = {z.real * z.real, z.imag * z.imag};
                        complex zn = {z2.real - z2.imag + c.real, 2.0 * z.real * z.imag + c.imag};

                        double mag = std::sqrt(z2.real + z2.imag);
                        if (mag > 2.5) {
                            double scalar = (double)i + 1.0 - std::log2(std::log2(mag));

                            constexpr double color_cycle = 0.04;

                            double color_scalar = scalar * color_cycle;
                            double blend = color_scalar - std::floor(color_scalar);

                            int _min = (int)std::floor(color_scalar) % num_colors;
                            int _max = (int)std::ceil(color_scalar) % num_colors;

                            normalized_rgb* c1 = &color_palette[_min];
                            normalized_rgb* c2 = &color_palette[_max];

                            color = {(Uint8)((c1->r + (c2->r - c1->r) * blend) * 255.0),(Uint8)((c1->g + (c2->g - c1->g) * blend) * 255.0), (Uint8)((c1->b + (c2->b - c1->b) * blend) * 255.0)};

                            break;
                        }

                        z = zn;
                    }

                    pixels[offset + dx] = color;

                }
            }
        }

        thread_barrier.arrive_and_wait();
    }
}

int main() {
    SDL_Init(SDL_INIT_EVENTS | SDL_INIT_VIDEO);

    threads.reserve(thread_count);
    pixels.resize(win_x * win_y);

    for (int i = 0; i < thread_count; ++i) {
        threads.emplace_back(execute_thread, i);
    }

    color_palette = {
        {0.0784, 0.3569, 0.8078},
        {0.6314, 0.8431, 0.9412},
        {0.9294, 0.9294, 0.949},
        {0.8471, 0.7725, 0.7294},
        {0.7294, 0.5294, 0.3412},
        {0.7569, 0.4471, 0.2118},
        {0.7294, 0.5294, 0.3412},
        {0.8471, 0.7725, 0.7294},
        {0.9294, 0.9294, 0.949},
        {0.6314, 0.8431, 0.9412}
    };

    SDL_Delay(200);

    SDL_Window* window = SDL_CreateWindow("Mandelbrot Set", win_x, win_y, SDL_WINDOW_RESIZABLE);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, nullptr);

    SDL_Texture* mandelbrot_texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y);
    SDL_Texture* escape_texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y);

    SDL_Event event;

    double last_cam_x = INFINITY;
    double last_cam_y = INFINITY;
    double last_zoom = 0;
    double last_res = 0;

    bool ctrl = false;
    bool shift = false;

    bool lock = false;
    bool inspect = false;

    float cam_speed = 15.0f;

    constexpr std::chrono::microseconds target_frame_time((int)1e6 / target_fps);
    std::chrono::microseconds frame_time;

    while (active) {
        std::chrono::high_resolution_clock::time_point frame_start = std::chrono::high_resolution_clock::now();

        SDL_SetRenderTarget(renderer, escape_texture);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
        SDL_RenderClear(renderer);

        while (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_EVENT_QUIT:
                active = false;

                break;

            case SDL_EVENT_MOUSE_MOTION:
                mouse_x = event.motion.x;
                mouse_y = event.motion.y;

                break;

            case SDL_EVENT_MOUSE_WHEEL:
                if (ctrl) {
                    zoom *= std::pow(1.03, event.wheel.y);
                } else if (shift) {
                    zoom *= std::pow(1.2, event.wheel.y);
                } else {
                    zoom *= std::pow(1.2, event.wheel.y);
                }
                
                inv_zoom = 1.0 / zoom;
                
                break;

            case SDL_EVENT_WINDOW_RESIZED:
                win_x = event.window.data1;
                win_y = event.window.data2;

                h_win_x = (double)win_x / 2.0; h_win_y = (double)win_y / 2.0;

                chunk = std::ceil((float)win_y / (float)thread_count);

                pixels.resize(win_x * win_y);

                SDL_DestroyTexture(mandelbrot_texture);
                SDL_DestroyTexture(escape_texture);

                mandelbrot_texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y);
                escape_texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y);

                window_updated = true;

                break;

            case SDL_EVENT_MOUSE_BUTTON_DOWN:
                if (event.button.button == SDL_BUTTON_LEFT) {
                    lmb = true;

                    lock = !lock;
                }

                break;

            case SDL_EVENT_MOUSE_BUTTON_UP:
                if (event.button.button == SDL_BUTTON_LEFT) {
                    lmb = false;
                }

            case SDL_EVENT_KEY_DOWN:
                switch (event.key.key) {
                case SDLK_SPACE:
                    inspect = !inspect;

                    break;

                case SDLK_1:
                    res = 50;
                    break;
                case SDLK_2:
                    res = 100;
                    break;
                case SDLK_3:
                    res = 200;
                    break;
                case SDLK_4:
                    res = 300;
                    break;
                case SDLK_5:
                    res = 400;
                    break;
                case SDLK_6:
                    res = 500;
                    break;
                case SDLK_7:
                    res = 650;
                    break;
                case SDLK_8:
                    res = 800;
                    break;
                case SDLK_9:
                    res = 1000;
                    break;
                case SDLK_0:
                    res = 1200;
                    break;
                case SDLK_MINUS:
                    res = 1500;
                    break;
                case SDLK_EQUALS:
                    res = 2000;
                    break;
                case SDLK_Z:
                    res = 2500;
                    break;
                case SDLK_X:
                    res = 3000;
                    break;
                case SDLK_C:
                    res = 4000;
                    break;
                case SDLK_V:
                    res = 5000;
                    break;
                case SDLK_B:
                    res = 6000;
                    break;
                case SDLK_N:
                    res = 8000;
                    break;
                case SDLK_M:
                    res = 10000;
                    break;
                }
            }
        }

        const bool* keys = SDL_GetKeyboardState(NULL);

        if (keys[SDL_SCANCODE_LCTRL]) {
            ctrl = true;
        } else {
            ctrl = false;
        }

        if (keys[SDL_SCANCODE_LSHIFT]) {
            shift = true;
        } else {
            shift = false;
        }

        if (shift) {
            cam_speed = 60.0f;
        } else {
            cam_speed = 15.0f;
        }

        if (keys[SDL_SCANCODE_W]) {
            cam_y -= cam_speed * inv_zoom;

        } else if (keys[SDL_SCANCODE_S]) {
            cam_y += cam_speed * inv_zoom;
        }
        if (keys[SDL_SCANCODE_A]) {
            cam_x -= cam_speed * inv_zoom;

        } else if (keys[SDL_SCANCODE_D]) {
            cam_x += cam_speed * inv_zoom;
        }

        thread_barrier.arrive_and_wait();

        thread_barrier.arrive_and_wait();

        if (last_cam_x != cam_x || last_cam_y != cam_y || last_zoom != zoom || last_res != res || window_updated) {
            last_cam_x = cam_x;
            last_cam_y = cam_y;
            last_zoom = zoom;
            last_res = res;
            window_updated = false;

            SDL_SetRenderTarget(renderer, mandelbrot_texture);

            for (int dy = 0; dy < win_y; ++dy) {
                int offset = dy * win_x;

                for (int dx = 0; dx < win_x; ++dx) {
                    rgb_color color = pixels[offset + dx];
                    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, 255);
                    SDL_RenderPoint(renderer, dx, dy);
                }
            }
        }

        if (inspect) {
            if (!lock) {
                escape_path.clear();

                complex c = {((double)mouse_x + 0.5 - h_win_x) * inv_zoom + cam_x, ((double)mouse_y + 0.5 - h_win_y) * inv_zoom + cam_y};

                complex z = {0.0, 0.0};

                rgb_color color{0,0,0};

                for (int i = 0; i < res; ++i) {
                    complex z2 = {z.real * z.real, z.imag * z.imag};
                    complex zn = {z2.real - z2.imag + c.real, 2.0 * z.real * z.imag + c.imag};

                    double mag = std::sqrt(z2.real + z2.imag);

                    escape_path.emplace_back(zn.real, zn.imag);

                    if (z2.real + z2.imag > 4.0) {
                        break;
                    }

                    z = zn;
                }
            }

            SDL_SetRenderDrawColor(renderer, 255, 0, 255, 255);

            SDL_SetRenderTarget(renderer, escape_texture);

            int size = escape_path.size();

            point p1 = escape_path.front();
            p1.x = std::clamp((p1.x - cam_x) * zoom + h_win_x, -1e4, 1e4);
            p1.y = std::clamp((p1.y - cam_y) * zoom + h_win_y, -1e4, 1e4);

            for (int i = 1; i < size; ++i) {
                point p2 = escape_path[i];
                p2.x = std::clamp((p2.x - cam_x) * zoom + h_win_x, -1e4, 1e4);
                p2.y = std::clamp((p2.y - cam_y) * zoom + h_win_y, -1e4, 1e4);

                SDL_RenderLine(renderer, p1.x, p1.y, p2.x, p2.y);

                p1 = p2;
            }
        }

        SDL_SetRenderTarget(renderer, nullptr);

        SDL_RenderTexture(renderer, mandelbrot_texture, nullptr, NULL);
        SDL_RenderTexture(renderer, escape_texture, nullptr, NULL);

        SDL_RenderPresent(renderer);

        std::chrono::high_resolution_clock::time_point frame_end = std::chrono::high_resolution_clock::now();

        frame_time = std::chrono::duration_cast<std::chrono::microseconds>(frame_end - frame_start);

        if (frame_time < target_frame_time) {
            std::this_thread::sleep_for(target_frame_time - frame_time);
        }

    }

    terminate_thread.store(true);

    thread_barrier.arrive_and_wait();

    for (int i = 0; i < thread_count; ++i) {
        threads[i].join();
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();

    return 0;
}
